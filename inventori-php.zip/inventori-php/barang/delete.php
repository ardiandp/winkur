<?php
// File: barang/delete.php
?>
