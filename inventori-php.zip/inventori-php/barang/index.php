<?php
// File: barang/index.php
?>
