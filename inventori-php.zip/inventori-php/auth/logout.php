<?php
// File: auth/logout.php
?>
