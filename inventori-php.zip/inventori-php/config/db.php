<?php
// File: config/db.php
?>
