<?php
// File: views/template/footer.php
?>
