<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body.dark-mode {
            background-color: #343a40;
            color: white;
        }
        .sidebar {
            width: 200px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        .sidebar-hidden {
            margin-left: -200px;
        }
    </style>
</head>
<body class="" id="body">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">ADMIN</a>
    <button class="btn btn-sm btn-outline-light ml-2" id="toggleSidebar">☰</button>
    <button class="btn btn-sm btn-outline-light ml-2" id="toggleDarkMode">🌓</button>
</nav>
