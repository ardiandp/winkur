    </div> <!-- End content area -->
</div> <!-- End wrapper -->

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('toggleSidebar').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('sidebar-hidden');
    });

    document.getElementById('toggleDarkMode').addEventListener('click', function () {
        document.getElementById('body').classList.toggle('dark-mode');
        let links = document.querySelectorAll('.nav-link');
        links.forEach(link => {
            link.classList.toggle('text-white');
        });
    });
</script>
</body>
</html>
