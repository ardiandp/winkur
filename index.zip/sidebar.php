<div class="d-flex">
    <div class="bg-light border sidebar" id="sidebar">
        <ul class="nav flex-column p-2">
            <li class="nav-item"><a href="index.php?page=dashboard" class="nav-link">Dashboard</a></li>
            <li class="nav-item">
                <a href="#" class="nav-link" data-toggle="collapse" data-target="#menu1">User Management</a>
                <div id="menu1" class="collapse">
                    <ul class="nav flex-column ml-3">
                        <li class="nav-item"><a href="index.php?page=users" class="nav-link">User List</a></li>
                        <li class="nav-item"><a href="#" class="nav-link">Add User</a></li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link" data-toggle="collapse" data-target="#menu2">Settings</a>
                <div id="menu2" class="collapse">
                    <ul class="nav flex-column ml-3">
                        <li class="nav-item"><a href="index.php?page=settings" class="nav-link">General</a></li>
                        <li class="nav-item"><a href="#" class="nav-link">Security</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
    <div class="flex-fill p-3" id="mainContent">
