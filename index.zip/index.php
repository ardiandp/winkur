<?php
$page = $_GET['page'] ?? 'dashboard';
include "header.php";
include "sidebar.php";
?>

<div class="container mt-4">
    <?php
    $path = "pages/$page.php";
    if (file_exists($path)) {
        include $path;
    } else {
        echo "<div class='alert alert-danger'>Halaman tidak ditemukan!</div>";
    }
    ?>
</div>

<?php include "footer.php"; ?>
