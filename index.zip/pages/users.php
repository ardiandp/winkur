<h3>Manajemen Pengguna</h3>
<div class="card">
    <div class="card-body">
        <table id="userTable" class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                <!-- Sample 11 rows -->
                <tr><td>1</td><td>Pengguna 1</td><td>user1@example.com</td><td>Admin</td></tr>
<tr><td>2</td><td>Pengguna 2</td><td>user2@example.com</td><td>Admin</td></tr>
<tr><td>3</td><td>Pengguna 3</td><td>user3@example.com</td><td>Admin</td></tr>
<tr><td>4</td><td>Pengguna 4</td><td>user4@example.com</td><td>Admin</td></tr>
<tr><td>5</td><td>Pengguna 5</td><td>user5@example.com</td><td>Admin</td></tr>
<tr><td>6</td><td>Pengguna 6</td><td>user6@example.com</td><td>Admin</td></tr>
<tr><td>7</td><td>Pengguna 7</td><td>user7@example.com</td><td>Admin</td></tr>
<tr><td>8</td><td>Pengguna 8</td><td>user8@example.com</td><td>Admin</td></tr>
<tr><td>9</td><td>Pengguna 9</td><td>user9@example.com</td><td>Admin</td></tr>
<tr><td>10</td><td>Pengguna 10</td><td>user10@example.com</td><td>Admin</td></tr>
<tr><td>11</td><td>Pengguna 11</td><td>user11@example.com</td><td>Admin</td></tr>

            </tbody>
        </table>
    </div>
</div>

<!-- CDN for jQuery, DataTables, Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css"/>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.bootstrap4.min.css"/>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>

<script>
$(document).ready(function() {
    $('#userTable').DataTable({
        dom: 'Bfrtip',
        buttons: ['excelHtml5', 'pdfHtml5']
    });
});
</script>
